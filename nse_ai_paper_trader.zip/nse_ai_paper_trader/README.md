# NSE AI Paper Trader

A beginner-friendly NSE stock analysis and paper-trading web app.

## Features
- NSE ticker lookup (for example `RELIANCE`, `TCS`, `INFY`; `.NS` is added automatically)
- Daily price chart with EMA 20 and EMA 50
- RSI 14 and MACD calculations
- Transparent BUY / SELL / HOLD indicator score
- Local SQLite paper-trade ledger with ₹100,000 virtual starting cash
- Holdings, realized/unrealized P&L, and trade history

## Requirements
- Python 3.10 or newer
- Internet connection for Yahoo Finance historical market data

## Run on Windows, macOS, or Linux

1. Extract this ZIP.
2. Open a terminal in the extracted `nse_ai_paper_trader` folder.
3. Create a virtual environment:

   Windows:
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

   macOS/Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install packages:
   ```bash
   pip install -r requirements.txt
   ```

5. Start the web app:
   ```bash
   streamlit run app.py
   ```

6. Open the local address printed in the terminal (usually http://localhost:8501).

## First test
- Search `RELIANCE` in the sidebar.
- Review the indicator explanations.
- Simulate a BUY for 1 share.
- Check the open position and trade history.
- Simulate a SELL to see the virtual cash and P&L update.

## Important limitations
- This is paper trading only. It does not connect to a broker or place real orders.
- Yahoo Finance data may be delayed, incomplete, rate-limited, or unavailable.
- The signal engine is a simple, explainable indicator score; it is not a trained AI model and does not predict prices.
- Fees, taxes, slippage, order-book liquidity, circuit limits, and corporate actions are not fully modeled.
- Never treat a backtest or indicator signal as a guarantee of future results.
